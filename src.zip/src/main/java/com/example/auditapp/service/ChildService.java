package com.example.auditapp.service;

import com.example.auditapp.entity.Child;
import com.example.auditapp.event.ChildRemovedEvent;
import com.example.auditapp.repository.ChildRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ChildService {

    @Autowired
    private ChildRepository childRepository;

    @Autowired
    private ApplicationEventPublisher eventPublisher;

    @Transactional
    public Child addChild(Child child) {
        return childRepository.save(child);
    }

    @Transactional
    public Child updateChild(Child child) {
        return childRepository.save(child);
    }

    @Transactional
    public void deleteChild(Long childId) {
        Child child = childRepository.findById(childId).orElseThrow(() -> new IllegalArgumentException("Child not found"));
        if (child.getParent() != null) {
            child.setTransientParentId(child.getParent().getId());
            // Publish the event for audit purposes
            eventPublisher.publishEvent(new ChildRemovedEvent<>(child.getId(), child.getTransientParentId(), Child.class));
        }
        childRepository.deleteById(childId);
    }
}
