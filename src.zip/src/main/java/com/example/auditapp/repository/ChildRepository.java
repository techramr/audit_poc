package com.example.auditapp.repository;

import com.example.auditapp.entity.Child;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ChildRepository extends JpaRepository<Child, Long> {
    // Additional query methods if needed
}
