package com.example.auditapp.listener;

import com.example.auditapp.event.ChildRemovedEvent;
import com.example.auditapp.service.GenericChildService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import jakarta.persistence.PreRemove;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import java.lang.reflect.Field;

@Component
public class ChildEntityListener {

    private static ApplicationContext applicationContext;

    @Autowired
    public void setApplicationContext(ApplicationContext applicationContext) {
        ChildEntityListener.applicationContext = applicationContext;
    }

    @PreRemove
    public void preRemove(Object entity) {
        try {
            Field parentField = entity.getClass().getDeclaredField("parent");
            parentField.setAccessible(true);
            Object parent = parentField.get(entity);
            if (parent != null) {
                Field parentIdField = parent.getClass().getDeclaredField("id");
                parentIdField.setAccessible(true);
                Long parentId = (Long) parentIdField.get(parent);
                Field transientParentIdField = entity.getClass().getDeclaredField("transientParentId");
                transientParentIdField.setAccessible(true);
                transientParentIdField.set(entity, parentId);
                System.out.println("The transientParentId @ PRE REMOVE IS " + parentId);
                GenericChildService<Object> childService = applicationContext.getBean(GenericChildService.class);
                childService.handleEntityRemoval((Long) getField(entity, "id"), parentId, (Class<Object>) entity.getClass());
            }
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    @EventListener
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void handleChildRemovedEvent(ChildRemovedEvent<?> event) {
        GenericChildService<Object> childService = applicationContext.getBean(GenericChildService.class);
        childService.updateParentId(event.getChildId(), event.getParentId(), (Class<Object>) event.getEntityType());
    }

    private Object getField(Object entity, String fieldName) throws NoSuchFieldException, IllegalAccessException {
        Field field = entity.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(entity);
    }
}
