package com.example.auditapp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.auditapp.listener.ChildEntityListener;

@Configuration
public class AppConfig {

    @Bean
    public ChildEntityListener childEntityListener() {
        return new ChildEntityListener();
    }
}
