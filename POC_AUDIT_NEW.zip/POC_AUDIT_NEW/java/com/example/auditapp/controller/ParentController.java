package com.example.auditapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.auditapp.entity.Parent;
import com.example.auditapp.service.ParentService;

@RestController
@RequestMapping("/api/parents")
public class ParentController {

	@Autowired
	private ParentService parentService;

	@PostMapping
	public Parent createParent(@RequestBody Parent parent) {
		System.out.println("Parent ID: " + parent.getId()); // Debugging
		if (parent.getId() != null)
			parent.setId(null);
		return parentService.saveParentWithChildren(parent);
	}

	@PutMapping("/{parentId}")
	public Parent updateParent(@PathVariable Long parentId, @RequestBody Parent updatedParent) {
		return parentService.updateParent(parentId, updatedParent);
	}

	@DeleteMapping("/{parentId}")
	public void deleteParent(@PathVariable Long parentId) {
		parentService.deleteParent(parentId);
	}
}
