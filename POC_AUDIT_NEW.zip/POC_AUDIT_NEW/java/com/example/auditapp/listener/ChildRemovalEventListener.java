package com.example.auditapp.listener;

import com.example.auditapp.event.ChildRemovedEvent;
import com.example.auditapp.service.GenericChildService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class ChildRemovalEventListener {

    @Autowired
    private ApplicationContext applicationContext;

    @EventListener
    public void handleChildRemovedEvent(ChildRemovedEvent<?> event) {
        GenericChildService childService = applicationContext.getBean(GenericChildService.class);
        childService.updateParentId(event.getChildId(), event.getParentId(), event.getEntityType());
    }
}
