package com.example.auditapp.listener;

import com.example.auditapp.entity.Child;
import com.example.auditapp.service.GenericChildService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import jakarta.persistence.PreRemove;

@Component
public class GenericChildEntityListener {

    private static ApplicationContext applicationContext;

    @Autowired
    public void setApplicationContext(ApplicationContext applicationContext) {
        GenericChildEntityListener.applicationContext = applicationContext;
    }

    @PreRemove
    public void preRemove(Object entity) {
        if (entity instanceof Child) {
            Child child = (Child) entity;
            if (child.getParent() != null) {
                child.setTransientParentId(child.getParent().getId()); // Capture the parent ID before deletion
                System.out.println("The child.getTransientParentId(); @ PRE REMOVE IS " + child.getTransientParentId());
                GenericChildService childService = applicationContext.getBean(GenericChildService.class);
                childService.handleEntityRemoval(child.getId(), child.getTransientParentId(), child.getClass());
            }
        }
    }
}
