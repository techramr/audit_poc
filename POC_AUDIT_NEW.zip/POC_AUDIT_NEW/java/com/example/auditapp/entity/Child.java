package com.example.auditapp.entity;

import org.hibernate.envers.Audited;

import com.example.auditapp.listener.GenericChildEntityListener;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Audited
@EntityListeners(GenericChildEntityListener.class)
@Getter
@Setter
public class Child {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "NAME")
    private String name;

    @Column(name = "VALUE_FIELD")
    private String valueField;

    @ManyToOne
    @JoinColumn(name = "parent_id", nullable = false)
    @JsonBackReference
    private Parent parent;

    @Transient // This field is not persisted to the database
    private Long transientParentId;

    @Column(name = "parent_id", insertable=false, updatable=false)
    private Long parentId; // Use the same name as the existing column
}
