package com.example.auditapp.service;

import com.example.auditapp.event.ChildRemovedEvent;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

@Service
public class GenericChildService {

    @PersistenceContext
    private EntityManager entityManager;

    private final ApplicationEventPublisher eventPublisher;

    public GenericChildService(ApplicationEventPublisher eventPublisher) {
        this.eventPublisher = eventPublisher;
    }

    @Transactional
    public <T> void handleEntityRemoval(Long childId, Long parentId, Class<T> entityType) {
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCommit() {
                eventPublisher.publishEvent(new ChildRemovedEvent<>(childId, parentId, entityType));
            }
        });
    }

    @TransactionalEventListener
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public <T> void handleChildRemovedEvent(ChildRemovedEvent<T> event) {
        updateParentId(event.getChildId(), event.getParentId(), event.getEntityType());
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public <T> void updateParentId(Long childId, Long parentId, Class<T> entityType) {
        String auditTableName = entityType.getSimpleName().toLowerCase() + "_aud";
        entityManager.createNativeQuery("UPDATE " + auditTableName + " SET parent_id = :parentId WHERE id = :id")
                .setParameter("parentId", parentId)
                .setParameter("id", childId)
                .executeUpdate();
    }
}
