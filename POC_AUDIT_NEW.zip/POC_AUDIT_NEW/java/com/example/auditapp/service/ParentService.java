package com.example.auditapp.service;

import com.example.auditapp.entity.Child;
import com.example.auditapp.entity.Parent;
import com.example.auditapp.repository.ParentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class ParentService {

    @Autowired
    private ParentRepository parentRepository;
    
   
    public Parent addParent(Parent parent) {
        return parentRepository.save(parent);
    }

    @Transactional
    public Parent updateParent(Long parentId, Parent updatedParent) {
        Optional<Parent> existingParent = parentRepository.findById(parentId);
        if (existingParent.isPresent()) {
            Parent parent = existingParent.get();
            parent.setName(updatedParent.getName());
            parent.setDescription(updatedParent.getDescription());
            
            // Synchronize children
            List<Child> updatedChildren = updatedParent.getChildren();
            List<Child> existingChildren = parent.getChildren();

            
         // Remove children that are no longer present in the updatedParent
            existingChildren.removeIf(child -> updatedChildren.stream()
                .noneMatch(updatedChild -> updatedChild.getId() != null && updatedChild.getId().equals(child.getId())));
            
            
            for (Child updatedChild : updatedChildren) {
                if (updatedChild.getId() == null) {
                    // New child: add it
                    updatedChild.setParent(parent);
                    existingChildren.add(updatedChild);
                } else {
                    // Existing child: update fields
                    existingChildren.stream()
                        .filter(existingChild -> existingChild.getId().equals(updatedChild.getId()))
                        .forEach(existingChild -> {
                            existingChild.setName(updatedChild.getName());
                            existingChild.setValueField(updatedChild.getValueField());
                        });
                }
            }

            // Save parent, cascading updates to children
            return parentRepository.save(parent);
        }
        throw new RuntimeException("Parent not found with ID: " + parentId);
    }

    public void deleteParent(Long parentId) {
        parentRepository.deleteById(parentId);
    }

    @Transactional
    public Parent saveParentWithChildren(Parent parent) {
        for (Child child : parent.getChildren()) {
            child.setParent(parent); // Ensure parent-child relationship
        }
        return parentRepository.save(parent);
    }
}
