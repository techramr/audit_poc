package com.example.auditapp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.auditapp.listener.GenericChildEntityListener;
import com.example.auditapp.listener.ChildRemovalEventListener;

@Configuration
public class AppConfig {

    @Bean
    public GenericChildEntityListener genericChildEntityListener() {
        return new GenericChildEntityListener();
    }

    @Bean
    public ChildRemovalEventListener childRemovalEventListener() {
        return new ChildRemovalEventListener();
    }
}
