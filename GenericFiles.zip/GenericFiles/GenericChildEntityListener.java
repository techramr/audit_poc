package com.example.auditdemo.listeners;

import java.lang.reflect.Field;
import java.util.List;
import java.util.logging.Logger;

import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.query.AuditEntity;
import org.hibernate.envers.query.AuditQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.example.auditdemo.entities.Child;
import com.example.auditdemo.entities.Parent;
import com.example.auditdemo.event.ChildRemovedEvent;
import com.example.auditdemo.services.GenericChildService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.PostUpdate;
import jakarta.persistence.PreRemove;

@Component
public class GenericChildEntityListener {

	private static final Logger LOGGER = Logger.getLogger(GenericChildEntityListener.class.getName());
	private static ApplicationContext applicationContext;

	 

	@Autowired
	public void setApplicationContext(ApplicationContext applicationContext) {
		GenericChildEntityListener.applicationContext = applicationContext;
	}
	
	private EntityManager getEntityManager() {
        return applicationContext.getBean(EntityManager.class);
    }

	@SuppressWarnings("unchecked")
	@PreRemove
	public void preRemove(Object entity) {

		LOGGER.info("The GenericChildEntityListener IS INVOKED-1111");

		try {
			Field parentField = entity.getClass().getDeclaredField("parent");
			parentField.setAccessible(true);
			Object parent = parentField.get(entity);

			if (parent != null) {
				Field parentIdField = parent.getClass().getDeclaredField("id");
				parentIdField.setAccessible(true);
				Long parentId = (Long) parentIdField.get(parent);

				Field transientParentIdField = entity.getClass().getDeclaredField("transientParentId");
				transientParentIdField.setAccessible(true);
				transientParentIdField.set(entity, parentId);

				LOGGER.info("The transientParentId @ PRE REMOVE IS " + transientParentIdField.get(entity));
				GenericChildService<Object> genericChildService = applicationContext.getBean(GenericChildService.class);
				genericChildService.handleEntityRemoval(getEntityId(entity), parentId, entity.getClass());
			}
		} catch (Exception e) {
			LOGGER.severe("Error in preRemove: " + e.getMessage());
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	@EventListener
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void handleChildRemovedEvent(ChildRemovedEvent<?> event) {

		LOGGER.info("The GenericChildEntityListener IS INVOKED-22222");

		GenericChildService<Object> genericChildService = applicationContext.getBean(GenericChildService.class);
		genericChildService.updateParentId(event.getChildId(), event.getParentId(), event.getEntityType());
	}

	@PostUpdate
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void postUpdate(Object entity) {
		try {
			if (entity instanceof Parent) {
				Parent parentEntity = (Parent) entity;
				Field parentIdField = parentEntity.getClass().getDeclaredField("id");
				parentIdField.setAccessible(true);
				Long parentId = (Long) parentIdField.get(parentEntity);

				GenericChildService<Object> genericChildService = applicationContext.getBean(GenericChildService.class);

				// Check if the parent entity and any of the children were updated
				boolean parentUpdated = isEntityModified(parentEntity);
				boolean childUpdated = false;

				if (parentEntity.getChildren() != null) {
					for (Child child : parentEntity.getChildren()) {
						if (isEntityModified(child)) {
							childUpdated = true;
							break; // Exit early if any child is modified
						}
					}
				}

				// If both parent and child entities are modified, update the audit tables
				if (parentUpdated && childUpdated) {
					LOGGER.info("Updating PARENT_AUD and CHILD_AUD for updated parent and children.");
					// Update the _MOD flag for Parent and Children in the audit tables
					genericChildService.updateModFlagsInAuditTables(parentId, null );
					if (parentEntity.getChildren() != null) {
						for (Child child : parentEntity.getChildren()) {
							Long childId = child.getId();
							// Update _MOD flag for Child in the audit table
							genericChildService.updateModFlagsInAuditTables(null, childId );
						}
					}
				}
			} else if (entity instanceof Child) {
				Child childEntity = (Child) entity;
				Long childId = childEntity.getId();
				Long parentId = childEntity.getParent().getId();

				GenericChildService<Object> genericChildService = applicationContext.getBean(GenericChildService.class);

				// Check if the child entity itself was modified
				boolean childUpdated = isEntityModified(childEntity);
				boolean parentUpdated = isEntityModified(childEntity.getParent());

				// Update _MOD flag for Child and Parent if both were modified
				if (childUpdated && parentUpdated) {
					LOGGER.info("Updating PARENT_AUD and CHILD_AUD for updated parent and child.");
					genericChildService.updateModFlagsInAuditTables(parentId, null );
					genericChildService.updateModFlagsInAuditTables(null, childId );
				}
			}
		} catch (Exception e) {
			LOGGER.severe("Error in postUpdate: " + e.getMessage());
			e.printStackTrace();
		}
	}

	// Helper method to check if an entity was modified
	private boolean isEntityModified(Object entity) {
		try {
			// Retrieve the session from the entity (assuming the entity has a getSession
			// method)
            EntityManager entityManager = getEntityManager();
			AuditReader auditReader = AuditReaderFactory.get(entityManager);

			// Fetch the entity's ID
			Object entityId = entity.getClass().getMethod("getId").invoke(entity);

			// Query for the latest revision of the entity
			AuditQuery query = auditReader.createQuery().forRevisionsOfEntity(entity.getClass(), false, true)
					.add(AuditEntity.id().eq(entityId)).addOrder(AuditEntity.revisionNumber().desc()); // Order by
																										// revision
																										// number in
																										// descending
																										// order to get
																										// the latest

			// Execute the query and fetch the result list
			List<?> revisions = query.getResultList();

			// If there are revisions, the entity was modified
			return !revisions.isEmpty(); // If a revision exists, it indicates a modification
		} catch (Exception e) {
			e.printStackTrace();
			return false; // Return false in case of any error (e.g., reflection issues)
		}
	}

	private Long getEntityId(Object entity) throws Exception {
		LOGGER.info("The GenericChildEntityListener IS INVOKED-33333");
		Field idField = entity.getClass().getDeclaredField("id");
		idField.setAccessible(true);
		return (Long) idField.get(entity);
	}
}
