package com.example.auditdemo.services;

import java.util.List;
import java.util.logging.Logger;

import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.example.auditdemo.entities.Child;
import com.example.auditdemo.entities.Parent;
import com.example.auditdemo.event.ChildRemovedEvent;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Service
public class GenericChildService<T> {

	private static final Logger LOGGER = Logger.getLogger(GenericChildService.class.getName());

	@PersistenceContext
	private EntityManager entityManager;

	private final ApplicationEventPublisher eventPublisher;

	public GenericChildService(ApplicationEventPublisher eventPublisher) {
		this.eventPublisher = eventPublisher;
	}

	@Transactional
	public void handleEntityRemoval(Long childId, Long parentId, Class<?> entityType) {
		LOGGER.info("GenericChildService --- handleEntityRemoval called with childId: " + childId + " and parentId: "
				+ parentId);
		TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
			@Override
			public void afterCommit() {
				eventPublisher.publishEvent(new ChildRemovedEvent<>(childId, parentId, entityType));
			}
		});
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void updateParentId(Long childId, Long parentId, Class<?> entityType) {
		String auditTableName = entityType.getSimpleName().toLowerCase() + "_aud";
		LOGGER.info("GenericChildService --- Updating parent_id in " + auditTableName + " for childId: " + childId
				+ " with parentId: " + parentId);
		entityManager
				.createNativeQuery("UPDATE " + auditTableName
						+ " SET parent_id = :parentId WHERE id = :id AND REVTYPE = 2 AND parent_id is NULL ")
				.setParameter("parentId", parentId).setParameter("id", childId).executeUpdate();
	}

	@Transactional
	public void updateModFlagsInAuditTables(Long parentId, Long childId) {
		
		LOGGER.info("INSIDE updateModFlagsInAuditTables.... parentId :: " + parentId + " childId :: " + childId);
		
		try {
			// Determine the audit table names
			String parentAuditTable = "parent_aud";
			String childAuditTable = "child_aud";
			String modFlagColumn;

			// If parentId is provided, update the parent audit table for the latest
			// revision
			if (parentId != null) {
				modFlagColumn = "CHILDREN_MOD";
				
				LOGGER.info("Updating " + modFlagColumn + " in " + parentAuditTable + " for parentId: " + parentId);

				// Use Envers to fetch the latest revision number for the parent
				int latestRevisionNumber = getLatestRevisionNumber(Parent.class, parentId);
				
				LOGGER.info("INSIDE Parent updateModFlagsInAuditTables -- latestRevisionNumber::::" + latestRevisionNumber );


				// Update only the latest revision for the parent entity in the parent_aud table
				if (latestRevisionNumber != -1) {
					entityManager
							.createNativeQuery("UPDATE " + parentAuditTable + " SET " + modFlagColumn
									+ " = TRUE WHERE id = :parentId AND REVTYPE = 1 AND REV = :rev")
							.setParameter("parentId", parentId).setParameter("rev", latestRevisionNumber)
							.executeUpdate();
				}
			}

			// If childId is provided, update the child audit table for the latest revision
			if (childId != null) {
				modFlagColumn = "PARENT_MOD";
				LOGGER.info("Updating " + modFlagColumn + " in " + childAuditTable + " for childId: " + childId);

				// Use Envers to fetch the latest revision number for the child
				int latestRevisionNumber = getLatestRevisionNumber(Child.class, childId);

				LOGGER.info("INSIDE Child updateModFlagsInAuditTables -- latestRevisionNumber:::: " + latestRevisionNumber );

				// Update only the latest revision for the child entity in the child_aud table
				if (latestRevisionNumber != -1) {
					entityManager
							.createNativeQuery("UPDATE " + childAuditTable + " SET " + modFlagColumn
									+ " = TRUE WHERE id = :childId AND REVTYPE = 1 AND REV = :rev")
							.setParameter("childId", childId).setParameter("rev", latestRevisionNumber).executeUpdate();
				}
			}

		} catch (Exception e) {
			LOGGER.severe("Error in updateModFlagsInAuditTables: " + e.getMessage());
			e.printStackTrace();
		}
	}

	// Helper method to get the latest revision number for an entity
	private int getLatestRevisionNumber(Class<?> entityClass, Long entityId) {
		try {
			// Create an AuditReader to query Envers audit tables
			AuditReader auditReader = AuditReaderFactory.get(entityManager);

			// Get the list of revisions for the entity (in ascending order)
			List<Number> revisions = auditReader.getRevisions(entityClass, entityId);

			// If revisions are found, return the most recent one (last in the list)
			if (!revisions.isEmpty()) {
				LOGGER.info("INSIDE getLatestRevisionNumber SIZE IS " + revisions.size());
				return revisions.get(revisions.size() - 1).intValue();
			}

			return -1; // No revisions found, return -1
		} catch (Exception e) {
			LOGGER.severe("Error getting latest revision number: " + e.getMessage());
			return -1;
		}
	}
}
