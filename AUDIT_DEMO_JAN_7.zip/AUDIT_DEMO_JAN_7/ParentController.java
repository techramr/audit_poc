package com.example.auditdemo.controllers;

import com.example.auditdemo.entities.Parent;
import com.example.auditdemo.services.ParentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/parents")
public class ParentController {

    @Autowired
    private ParentService parentService;

    @PostMapping
    public Parent createParent(@RequestBody Parent parent) {
        return parentService.saveParent(parent);
    }

    @GetMapping
    public List<Parent> getAllParents() {
        return parentService.getAllParents();
    }

    @GetMapping("/{parentId}")
    public Optional<Parent> getParentWithChildren(@PathVariable Long parentId) {
        return parentService.getParentWithChildren(parentId);
    }

    @PutMapping("/{parentId}")
    public Parent updateParent(@PathVariable Long parentId, @RequestBody Parent updatedParent) {
        return parentService.updateParent(parentId, updatedParent);
    }

    @DeleteMapping("/{parentId}")
    public void deleteParent(@PathVariable Long parentId) {
        parentService.deleteParent(parentId);
    }
}
