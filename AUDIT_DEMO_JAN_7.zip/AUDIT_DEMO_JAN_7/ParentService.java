package com.example.auditdemo.services;

import com.example.auditdemo.entities.Parent;
import com.example.auditdemo.repositories.ParentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class ParentService {

    @Autowired
    private ParentRepository parentRepository;

    public Parent saveParent(Parent parent) {
        return parentRepository.save(parent);
    }

    public List<Parent> getAllParents() {
        return parentRepository.findAll();
    }

    public Optional<Parent> getParentWithChildren(Long parentId) {
        return parentRepository.findById(parentId);
    }

    @Transactional
    public Parent updateParent(Long parentId, Parent updatedParent) {
        Optional<Parent> existingParentOptional = parentRepository.findById(parentId);
        if (existingParentOptional.isPresent()) {
            Parent existingParent = existingParentOptional.get();
            existingParent.setName(updatedParent.getName());
            existingParent.setDescription(updatedParent.getDescription());
            
            // Clear and update children to track modifications correctly
            existingParent.getChildren().forEach(child -> child.setParent(null));
            existingParent.getChildren().clear();
            updatedParent.getChildren().forEach(child -> {
                child.setParent(existingParent);
                existingParent.getChildren().add(child);
            });

            return parentRepository.save(existingParent);
        } else {
            throw new RuntimeException("Parent not found with id " + parentId);
        }
    }

    @Transactional
    public void deleteParent(Long parentId) {
        parentRepository.deleteById(parentId);
    }
}
