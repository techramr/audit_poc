package com.example.auditdemo.event;

public class ChildRemovedEvent<T> {
    private final Long childId;
    private final Long parentId;
    private final Class<T> entityType;

    public ChildRemovedEvent(Long childId, Long parentId, Class<T> entityType) {
        this.childId = childId;
        this.parentId = parentId;
        this.entityType = entityType;
    }

    public Long getChildId() {
        return childId;
    }

    public Long getParentId() {
        return parentId;
    }

    public Class<T> getEntityType() {
        return entityType;
    }
}
