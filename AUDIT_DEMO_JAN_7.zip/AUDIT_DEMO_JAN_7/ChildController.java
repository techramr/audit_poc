
package com.example.auditdemo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.auditdemo.entities.Child;
import com.example.auditdemo.services.ChildService;

@RestController
@RequestMapping("/api/children")
public class ChildController {
	@Autowired
	private ChildService childService;

	@PostMapping
	public Child createChild(@RequestBody Child child) {
		return childService.saveChild(child);
	}

	@GetMapping
	public List<Child> getAllChildren() {
		return childService.getAllChildren();
	}
// Other endpoints... 
}