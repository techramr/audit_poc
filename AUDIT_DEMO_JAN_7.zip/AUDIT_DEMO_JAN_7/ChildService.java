package com.example.auditdemo.services;

import com.example.auditdemo.entities.Child;
import com.example.auditdemo.event.ChildRemovedEvent;
import com.example.auditdemo.repositories.ChildRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class ChildService {

    @Autowired
    private ChildRepository childRepository;

    @Autowired
    private ApplicationEventPublisher applicationEventPublisher;

    public Child saveChild(Child child) {
        return childRepository.save(child);
    }

    public List<Child> getAllChildren() {
        return childRepository.findAll();
    }

    @Transactional
    public void deleteChild(Long childId) {
        Optional<Child> childOptional = childRepository.findById(childId);
        if (childOptional.isPresent()) {
            Child child = childOptional.get();
            // Publish the ChildRemovedEvent before deletion
            applicationEventPublisher.publishEvent(new ChildRemovedEvent<>(child.getId(), child.getTransientParentId(), Child.class));
            childRepository.delete(child);
        }
    }

    public void handleEntityRemoval(Long childId, Long parentId, Class<Child> entityType) {
        // Logic to handle removal
    }

    @Transactional
    public void updateParentId(Long childId, Long parentId, Class<Child> entityType) {
        // Logic to update the parent ID, if needed
    }
}
