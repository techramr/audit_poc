package com.example.auditdemo.services;

import com.example.auditdemo.event.ChildRemovedEvent;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.logging.Logger;

@Service
public class GenericChildService<T> {

    private static final Logger LOGGER = Logger.getLogger(GenericChildService.class.getName());

    @PersistenceContext
    private EntityManager entityManager;

    private final ApplicationEventPublisher eventPublisher;

    public GenericChildService(ApplicationEventPublisher eventPublisher) {
        this.eventPublisher = eventPublisher;
    }

    @Transactional
    public void handleEntityRemoval(Long childId, Long parentId, Class<?> entityType) {
        LOGGER.info("handleEntityRemoval called with childId: " + childId + " and parentId: " + parentId);
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCommit() {
                eventPublisher.publishEvent(new ChildRemovedEvent<>(childId, parentId, entityType));
            }
        });
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateParentId(Long childId, Long parentId, Class<?> entityType) {
        String auditTableName = entityType.getSimpleName().toLowerCase() + "_aud";
        LOGGER.info("Updating parent_id in " + auditTableName + " for childId: " + childId + " with parentId: " + parentId);
        entityManager.createNativeQuery("UPDATE " + auditTableName + " SET parent_id = :parentId WHERE id = :id")
                .setParameter("parentId", parentId)
                .setParameter("id", childId)
                .executeUpdate();
    }
}
