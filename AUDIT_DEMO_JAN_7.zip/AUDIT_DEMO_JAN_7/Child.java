package com.example.auditdemo.entities;

import org.hibernate.envers.Audited;

import com.example.auditdemo.listeners.GenericChildEntityListener;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreRemove;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@Audited(withModifiedFlag = true)
@EntityListeners(GenericChildEntityListener.class)
@AllArgsConstructor
@NoArgsConstructor
public class Child {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private String valueChild;
	
	
	@ManyToOne
	@JoinColumn(name = "parent_id", nullable = false)
	@JsonBackReference
	private Parent parent;
	
	
	@Transient
	private Long transientParentId;

	@PrePersist
	@PreUpdate
	@PreRemove
	private void syncTransientParentId() {
		this.transientParentId = parent != null ? parent.getId() : null;
	}
}