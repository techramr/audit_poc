package com.example.auditdemo.listeners;

import com.example.auditdemo.event.ChildRemovedEvent;
import com.example.auditdemo.services.GenericChildService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import jakarta.persistence.PreRemove;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Field;
import java.util.logging.Logger;

@Component
public class GenericChildEntityListener {

    private static final Logger LOGGER = Logger.getLogger(GenericChildEntityListener.class.getName());
    private static ApplicationContext applicationContext;

    @Autowired
    public void setApplicationContext(ApplicationContext applicationContext) {
        GenericChildEntityListener.applicationContext = applicationContext;
    }

    @SuppressWarnings("unchecked")
	@PreRemove
    public void preRemove(Object entity) {
        try {
            Field parentField = entity.getClass().getDeclaredField("parent");
            parentField.setAccessible(true);
            Object parent = parentField.get(entity);

            if (parent != null) {
                Field parentIdField = parent.getClass().getDeclaredField("id");
                parentIdField.setAccessible(true);
                Long parentId = (Long) parentIdField.get(parent);

                Field transientParentIdField = entity.getClass().getDeclaredField("transientParentId");
                transientParentIdField.setAccessible(true);
                transientParentIdField.set(entity, parentId);

                LOGGER.info("The transientParentId @ PRE REMOVE IS " + transientParentIdField.get(entity));
                GenericChildService<Object> genericChildService = applicationContext.getBean(GenericChildService.class);
                genericChildService.handleEntityRemoval(getEntityId(entity), parentId, entity.getClass());
            }
        } catch (Exception e) {
            LOGGER.severe("Error in preRemove: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
	@EventListener
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void handleChildRemovedEvent(ChildRemovedEvent<?> event) {
        GenericChildService<Object> genericChildService = applicationContext.getBean(GenericChildService.class);
        genericChildService.updateParentId(event.getChildId(), event.getParentId(), event.getEntityType());
    }

    private Long getEntityId(Object entity) throws Exception {
        Field idField = entity.getClass().getDeclaredField("id");
        idField.setAccessible(true);
        return (Long) idField.get(entity);
    }
}
