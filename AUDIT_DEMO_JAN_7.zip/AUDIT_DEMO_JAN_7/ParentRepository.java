
package com.example.auditdemo.repositories;

import com.example.auditdemo.entities.Parent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParentRepository extends JpaRepository<Parent, Long> {
}
        