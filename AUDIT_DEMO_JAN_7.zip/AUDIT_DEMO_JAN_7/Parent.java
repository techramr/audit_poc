package com.example.auditdemo.entities;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.envers.Audited;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Entity
@Audited(withModifiedFlag = true)
public class Parent {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private String description;
	@OneToMany(mappedBy = "parent", cascade = CascadeType.ALL, orphanRemoval = true)
	@JsonManagedReference
	private List<Child> children = new ArrayList<>();

	public void addChild(Child child) {
		child.setParent(this);
		children.add(child);
	}

	public void removeChild(Child child) {
		child.setParent(null);
		children.remove(child);
	}
}