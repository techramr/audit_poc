
package com.example.auditdemo.repositories;

import com.example.auditdemo.entities.Child;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChildRepository extends JpaRepository<Child, Long> {
}
        